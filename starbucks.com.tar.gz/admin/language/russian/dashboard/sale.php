<?php
// Heading
$_['heading_title'] = 'Продаж';

// Text
$_['text_view']     = 'подробнее...';

