<?php
// Text
$_['text_title'] = 'Credit Card / Debit Card (2Checkout)';

